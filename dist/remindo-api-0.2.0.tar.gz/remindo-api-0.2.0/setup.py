# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['remindo_api']

package_data = \
{'': ['*']}

install_requires = \
['configparser==3.5.0',
 'pandas==0.25.3',
 'pycryptodome>=3.9.9,<4.0.0',
 'requests>=2.23.0,<3.0.0',
 'six>=1.15.0,<2.0.0',
 'sphinx>=3.1.2,<4.0.0',
 'urllib3==1.26.3']

setup_kwargs = {
    'name': 'remindo-api',
    'version': '0.2.0',
    'description': 'API wrapper for Remindo',
    'long_description': None,
    'author': 'Leonardo Vida',
    'author_email': 'lleonardovida@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/leonardovida>/remindo-api',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
